<audio controls autoplay="" hidden=""> 
  <source src="CAMERA.mp3" type="audio/mpeg" />
Your browser does not support the audio element.
</audio>
  <?php     
	include('../setting.php');
 ?>
 
        <?php
           if($_GET['noperk']!=null)
           {?>
             
           <?php
                $nomor=Strtoupper($_GET['noperk']);
                $dawane=Strlen($nomor);
                if($dawane==7)
                {
                   $noperk= $nomor; 
                }else
                if($dawane==6)
                {
                   $noperk= '0'.$nomor; 
                }
                else
                if($dawane==5)
                {
                   $noperk= '00'.$nomor; 
                }else
                if($dawane==4)
                {
                   $noperk= '000'.$nomor; 
                }
                $nomorperkara=substr($noperk,0,4).'  -  '.substr($noperk,4,1).' - 20'.substr($noperk,5,2);
                $nomoreperkara=substr($noperk,0,4).'/Pdt.'.substr($noperk,4,1).'/ 20'.substr($noperk,5,2).'/'.$kodepa;
                $tekek =date("m-d-Y"); 
                $x = mssql_query("SELECT top 1 NO_PERK, RUANG, NU                                
                                 FROM DATA_SIDANG
                                WHERE TANGGAL='$tekek' AND NO_PERK='$noperk' ");
                $ada = mssql_num_rows($x); 
				while($data = mssql_fetch_array($x))
                {
                    $noperk=$data['NO_PERK'];
                    $ruang=$data['RUANG'];
                    $NU=$data['NU'];
                    if($NU==990 OR $NU==null)
                    {
                         //CEK ANTRIAN TERAKIR
                            $xx = mssql_query("SELECT top 1  NU                                
                                         FROM DATA_SIDANG
                                        WHERE TANGGAL='$tekek' AND RUANG='$ruang' AND NU<>990  ORDER BY NU DESC ");
                            $jml = mssql_num_rows($xx); 
            				while($datax = mssql_fetch_array($xx))
                            {
                               
                                 $urutan=$datax['NU']+1;
                                
                            }
                            if($jml==NULL)
                            {
                                $urutan=1;
                            }
                            mssql_query("UPDATE DATA_SIDANG SET NU=$urutan  
                                     WHERE TANGGAL='$tekek' AND NO_PERK='$noperk' ");
                            
                    } else
                    {
                        $urutan=$NU; 
                    }
                    
                    //kata
                    
                    $kata="NOMOR PERKARA   -   ".$nomorperkara. "   
                    
                    RUANG SIDANG    -  ".$ruang. "        
                      
                      ANTRIAN     -    ".$urutan;
                    //
                    
                    //cek identitas
                     $rs =mssql_query("SELECT  top 1 NO_PERK, 
                    (select   NAMA  from   DATA_BIODATA where NO_PERK=DATA_REGISTER.NO_PERK AND fungsi=1001 AND TINGKAT=DATA_REGISTER.TINGKAT) as nama_p, 
                    (select   NAMA  from   DATA_BIODATA where NO_PERK=DATA_REGISTER.NO_PERK AND fungsi=1002 AND TINGKAT=DATA_REGISTER.TINGKAT) as nama_t
                     
                    FROM DATA_REGISTER WHERE NO_PERK='$noperk' order by TINGKAT DESC" ); 
                    while($bio = mssql_fetch_array($rs))
                        {
                            $nama_p=$bio['nama_p'];
                            $nama_t=$bio['nama_t'];    
                        }       
                    
                    //cek identitas
                    ?>
                    
                    <?php
                    echo "<center>Nomor Perk :    ".$nomoreperkara. "   <br>
                    
                    R. Sidang : ".$ruang. "         <br>
                      
                      Antrian :  ".$urutan."</center>";
                }
                if($ada==null)
                {
                    $kata="Nomor Perkara tidak ada pada daftar sidang hari ini.  Keterangan lebih lanjut, Hubungi Bagian Kepaniteraan";
                    echo "<font color='red'><br>Nomor Perkara tidak ada pada daftar sidang hari ini<br>keterangan lebih lanjut, Hubungi Bagian Kepaniteraan</font>";
                }
              //isi suara
              mssql_query("UPDATE MS_RUN SET SPOKE='$kata'  
                                     WHERE ruang=999");
              
              //isi suara 	
           mssql_close($dbhandle)   ;	 
        
        
        
           } 
        ?>
         
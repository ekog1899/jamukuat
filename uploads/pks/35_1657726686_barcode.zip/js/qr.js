function read(a)
{
    $("#qr-value").text(a);
    $("#noperk").val(a);
    $("#surachman").submit(); 
}    
    
qrcode.callback = read;

<html>
    <head>
        <title>Pendaftaran Sidang Barcode </title>
        <style>
        #papan {
margin: 50px 30px;
position: fixed;
top:0;

right:0;
 

}
        #keyboard {
margin: 0;
padding: 0;
list-style: none;
}
    #keyboard li {
    float: left;
    margin: 0 5px 5px 0;
    width: 80px;
    height: 80px;
    line-height: 80px;
    text-align: center;
    background: #fff;
    border: 1px solid #f9f9f9;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    font-size: 30px;
    }
        .delete, .kiri{
        clear: left;
        }
             
            #keyboard .return {
            width: 160px;
            }
             #keyboard .delete {
            width: 160px;
            } 
        .lastitem {
        margin-right: 0;
        }
         
        #keyboard li:hover {
        position: relative;
        top: 1px;
        left: 1px;
        border-color: #e5e5e5;
        cursor: pointer;
        }
        </style>
        <script type="text/javascript" src="js/lib/jquery-1.7.2.min.js"></script>

        <script type="text/javascript" src="js/lib/jsqrcode/grid.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/version.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/detector.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/formatinf.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/errorlevel.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/bitmat.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/datablock.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/bmparser.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/datamask.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/rsdecoder.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/gf256poly.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/gf256.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/decoder.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/QRCode.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/findpat.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/alignpat.js"></script>
        <script type="text/javascript" src="js/lib/jsqrcode/databr.js"></script>

        <script type="text/javascript" src="js/qr.js"></script>
        <script type="text/javascript" src="js/camera.js"></script>
        <script type="text/javascript" src="js/init.js"></script>
    </head>
    <body onload="document.surachman.noperk.focus()" style="background: #E5E5E5 ;">  
    <center>
        <video  id="camsource" autoplay="true" width="320" height="320" style="display:none  ">Put your fallback message here.</video>
        <canvas id="qr-canvas" width="320" height="320" style="display: normal"></canvas>
        <br /><h3  id="qr-value" style="display: none;"> </h3>
        <form action="index1.php" method="GET"  id="surachman" name="surachman">
        
        <input type="text"  id="noperk" name="noperk" value="" autocomplete="off" maxlength="7" style=" 
            font-size: 50px;
            display: block; 
            width: 240px;
            height: 75px;
            padding: 6px 12px; 
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px; 
            -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
            -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;"/> 
        <div class="buttons"> <span id="error" style="display:none; color:#F00">Some Error!Please Fill form Properly </span> <span id="success" style="display:none; font-size:40px; color:#0C0; ">Pembacaan Sukses!<br><img src="../ok.gif"></span>

       
         <script>
             $(document).ready(function(){
            $('#surachman').on('submit',function(e) {
            
            $.ajax({
            url:'index1.php',
            data:$(this).serialize(),

            type:'GET',
            success:function(data){
            console.log(data);
            
            
            $("#success").html(data);
            $("#success").show().fadeOut(5000);
            $('#noperk').val('');
             //=== Show Success Message==
            },
            error:function(data){
            $("#error").show().fadeOut(5000); //===Show Error Message====
            }
            });
            
            e.preventDefault(); //=== To Avoid Page Refresh and Fire the Event "Click"===
            });
            });
         </script> 
        </center>
 <div id="papan"> 
 
    <ul id="keyboard">
        <li class="kiri">7</li>
		<li class="letter">8</li>
		<li class="letter">9</li>
		<li class="P lastitem">P</li>
        <li class="kiri">4</li>
		<li class="letter">5</li>
		<li class="letter">6</li>
		<li class="letter lastitem">G</li>
		
		<li class="kiri">0</li>
		<li class="letter">1</li>
		<li class="letter">2</li>
		<li class="letter lastitem">3</li>
		 
		<li class="delete kiri">Hapus</li> 
		<li class="return lastitem"><input value="OK" type="submit" style="float: left;
    margin: 0 5px 5px 0;
    width: 160px;
    height: 80px;
    line-height: 80px;
    text-align: center;
    background: #fff;
    border: 1px solid #f9f9f9;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    font-size: 30px;" /> </li> 
    </ul>
</div>
<script>
$(function(){
    var $noperk = $('#noperk');
     
    $('#keyboard li').click(function(){
        var $this = $(this),
            character = $this.text();  
         
         
        // Delete
        if ($this.hasClass('delete')) {
            var html = $noperk.val();
             
            $noperk.val(html.substr(0, html.length - 1));
            return false;
        }
         
        // Special characters
         
        if ($this.hasClass('return')) character = "\n";
		if ($this.hasClass('P')) character = "P";
		if ($this.hasClass('G')) character = "G";
         
         
         
         
        // Add the character
        $noperk.val($noperk.val() + character);
    });
});
</script>
 </form>
    </body>
</html>